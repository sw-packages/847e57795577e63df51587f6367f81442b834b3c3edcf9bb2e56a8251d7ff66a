//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTDEEPSCANLINEHUGE_H_
#define TESTDEEPSCANLINEHUGE_H_

void testDeepScanLineHuge (const std::string& tempDir);

#endif /* TESTDEEPSCANLINEHUGE_H_ */
