//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTMULTIPARTFILEMIXINGBASIC_H_
#define TESTMULTIPARTFILEMIXINGBASIC_H_

#include <string>

void testMultiPartFileMixingBasic (const std::string& tempDir);

#endif /* TESTMULTIPARTFILEMIXINGBASIC_H_ */
